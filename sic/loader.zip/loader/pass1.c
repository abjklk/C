/*
        SIC/XE Linking Loader Pass - 1
    
    Author : abjklk
    Credits to Nitish for stringthex()
    Comments : Please add this stuff to ESTAB yourself. oNlY FoR ReFerEnCe
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int stringthex(char z[4])
{
    z=strrev(z);
    int k=0,hex=0;
    while(z[k]!='\0')
    {
        if(z[k]=='A'||z[k]=='B'||z[k]=='C'||z[k]=='D'||z[k]=='E'||z[k]=='F')
            hex+=(int)(z[k]-55)*(pow(16,k));
        else if(z[k]=='a'||z[k]=='b'||z[k]=='c'||z[k]=='d'|z[k]=='e'||z[k]=='f') 
              hex+=(int)(z[k]-87)*(pow(16,k));
        else
            hex+=(int)(z[k]-48)*(pow(16,k));
        k++;
    }
    z=strrev(z);
    return hex;
}

int main()
{
    //Basic C BS
    FILE *fin;
    char inbuf[200];    
    int progaddr, csaddr, cslth, i, j;
    int ct=0;
    char *tok;
    
    //Not 1,Not 2, *T H R E E* dimensional array 
    char arr[100][50][10];

    //To get no. of tokens in each line
    int lines[100];

    //Dont mess with the input file! 
    fin = fopen("input.txt","r");

    //Populate Array
    while ((fscanf(fin, "%[^\n]%*c", inbuf)) != EOF )
	{
		// printf("%s\n",inbuf);
        tok = strtok(inbuf," ");
        i=0;
        while (tok!= NULL)
        {
            // printf("words: %s\n",tok);
            strcpy(arr[ct][i],tok);
            i++;
            tok = strtok(NULL," ");
        }
        lines[ct] = i;
        ct++;
    }

    //Enough of files
    fclose(fin);
    
    //Ask politely & no exceptions
    printf("Enter Starting Address: \n");
    scanf("%x", &progaddr);

    //set CSADDR to PROGADDR {for first control section}
    csaddr = progaddr;
    
    //The game begins
    for(i=0;i<ct;i++)
    { 
        //if head record
        if(arr[i][0][0] == 'H')
        {
            //set CSLTH to control section length 
            cslth = stringthex(arr[i][lines[i]-1]);
            
            // printf("Cslth is %x\n",cslth);

            //Display result
            printf("%s - %04X\n",arr[i][1],csaddr);
        }

        //if Define record
        else if(arr[i][0][0] == 'D')
        {
            //For every symbol and address in the rec
            for(j=1;j<lines[i];j++)
                
                //Even is addr, Odd is symbol
                if(j % 2 == 1)
                    printf("%s - ",arr[i][j]);
                else
                {
                    //enter symbol with value(CSADDR + indicated address) 
                    printf("%04X\n",csaddr+stringthex(arr[i][j]));
                }
        }

        //If end of CS is reached (Note: not end of file. E & END are different )
        else if(strcmp(arr[i][0],"E") == 0)
        {
            //add CSLTH to CSADDR {starting address for next control section} 
            csaddr += cslth;
        }
    }
    //Game over

    //Dont leave him hanging
    return 0;
}