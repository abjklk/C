# tcp-client-server-in-C

See the explanation in this video: https://www.youtube.com/watch?v=hptViBE23fI

This is a simple TCP Client Server program in C language. 
